
import { useEffect, useMemo, useState } from "react";
import StatusBadge from "../components/common/StatusBadge";
import Modal from "../components/common/Modal";

const API = "http://localhost:8080/api";

export default function Receiving({ notify }) {
  const [records, setRecords] = useState([]);
  const [products, setProducts] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [locations, setLocations] = useState([]);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    productId: "",
    supplierId: "",
    warehouseId: "1",
    locationId: "",
    receivedQuantity: "",
    receivedDate: new Date().toISOString().slice(0, 10),
    status: "COMPLETED",
  });

  const loadData = async () => {
    try {
      const responses = await Promise.all([
        fetch(`${API}/receiving`),
        fetch(`${API}/products`),
        fetch(`${API}/suppliers`),
        fetch(`${API}/warehouses/locations`),
      ]);

      if (responses.some((r) => !r.ok)) {
        throw new Error("Unable to load receiving data");
      }

      const [rData, pData, sData, lData] = await Promise.all(
        responses.map((r) => r.json())
      );

      setRecords(rData);
      setProducts(pData.map((p) => ({
        productId: String(p.PRODUCT_ID ?? p.productId ?? ""),
        productName: p.PRODUCT_NAME ?? p.productName ?? "",
      })));
      setSuppliers(sData.map((s) => ({
        supplierId: String(s.SUPPLIER_ID ?? s.supplierId ?? ""),
        supplierName: s.SUPPLIER_NAME ?? s.supplierName ?? "",
      })));
      setLocations(lData.map((l) => ({
        locationId: Number(l.LOCATION_ID ?? l.locationId),
        code: l.LOCATION_CODE ?? l.locationCode ?? l.code ?? "",
        zone: l.LOCATION_TYPE ?? l.locationType ?? l.zone ?? "",
        warehouseId: Number(l.WAREHOUSE_ID ?? l.warehouseId ?? 1),
      })));
    } catch (error) {
      console.error("Receiving loading error:", error);
      notify?.("Unable to load receiving data. Check backend and warehouse locations.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (!products.length || !suppliers.length) return;
    setForm((old) => ({
      ...old,
      productId: old.productId || products[0].productId,
      supplierId: old.supplierId || suppliers[0].supplierId,
      locationId: old.locationId || (locations[0] ? String(locations[0].locationId) : ""),
    }));
  }, [products, suppliers, locations]);

  const rows = useMemo(() => {
    const text = (v) => String(v ?? "").toLowerCase();
    return records.filter((r) =>
      `${r.RECEIVING_ID ?? r.receivingId ?? ""} ${
        r.PRODUCT_ID ?? r.productId ?? ""
      } ${r.SUPPLIER_NAME ?? r.supplierName ?? ""} ${
        r.SUPPLIER ?? r.supplier ?? ""
      } ${r.PRODUCT_NAME ?? r.productName ?? ""}`
        .toLowerCase()
        .includes(q.toLowerCase())
    );
  }, [records, q]);

  const add = () => {
    setForm((old) => ({
      ...old,
      productId: products[0]?.productId || "",
      supplierId: suppliers[0]?.supplierId || "",
      warehouseId: String(locations[0]?.warehouseId || 1),
      locationId: locations[0] ? String(locations[0].locationId) : "",
      receivedQuantity: "",
      receivedDate: new Date().toISOString().slice(0, 10),
      status: "COMPLETED",
    }));
    setOpen(true);
  };

  const save = async (e) => {
    e.preventDefault();
    const qty = Number(form.receivedQuantity);

    if (!form.productId || !form.supplierId || !form.locationId) {
      notify?.("Select product, supplier and location", "error");
      return;
    }
    if (!Number.isFinite(qty) || qty <= 0) {
      notify?.("Enter a valid receiving quantity", "error");
      return;
    }

    const selectedLocation = locations.find(
      (l) => l.locationId === Number(form.locationId)
    );

    const payload = {
      productId: form.productId,
      supplierId: form.supplierId,
      warehouseId: Number(selectedLocation?.warehouseId || form.warehouseId || 1),
      locationId: Number(form.locationId),
      receivedQuantity: qty,
      receivedDate: form.receivedDate,
      status: form.status,
    };

    setSaving(true);
    try {
      const response = await fetch(`${API}/receiving`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const message = await response.text();
        throw new Error(message || "Could not receive stock");
      }

      await loadData();
      setOpen(false);
      notify?.("Receiving record saved successfully");
    } catch (error) {
      console.error("Save receiving error:", error);
      notify?.(`Receiving failed: ${error.message}`, "error");
    } finally {
      setSaving(false);
    }
  };

  const value = (r, upper, lower) => r[upper] ?? r[lower] ?? "";

  return (
    <div className="page-content">
      <div className="page-title action-title">
        <div>
          <h1>Receiving &amp; Putaway</h1>
          <p>Receive incoming stock and put it into a warehouse location.</p>
        </div>
        <button className="primary-button" onClick={add}>
          ＋ New Receiving
        </button>
      </div>

      <section className="section-card">
        <div className="filter-bar">
          <div className="search-field wide">
            <span>⌕</span>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search receiving ID, supplier or product..."
            />
          </div>
        </div>

        <div className="result-count">
          {loading ? "Loading receiving records..." : `${rows.length} records found`}
        </div>

        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Supplier</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Location</th>
                <th>Date</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => {
                const id = value(r, "RECEIVING_ID", "receivingId");
                const productId = String(value(r, "PRODUCT_ID", "productId"));
                const locationId = Number(value(r, "LOCATION_ID", "locationId"));
                const product = products.find((p) => p.productId === productId);
                const location = locations.find((l) => l.locationId === locationId);
                const productName =
                  value(r, "PRODUCT_NAME", "productName") ||
                  product?.productName ||
                  productId;
                const supplierName =
                  value(r, "SUPPLIER_NAME", "supplierName") ||
                  value(r, "SUPPLIER", "supplier") ||
                  suppliers.find(
                    (s) => s.supplierId === String(value(r, "SUPPLIER_ID", "supplierId"))
                  )?.supplierName ||
                  "—";
                const date = value(r, "RECEIVED_DATE", "receivedDate");
                const dateText = date
                  ? String(date).slice(0, 10)
                  : "—";

                return (
                  <tr key={id || i}>
                    <td>R{String(id).slice(-4)}</td>
                    <td>{supplierName}</td>
                    <td>{productName}</td>
                    <td>{value(r, "RECEIVED_QUANTITY", "receivedQuantity")}</td>
                    <td>
                      {value(r, "LOCATION_CODE", "locationCode") ||
                        location?.code ||
                        (locationId ? `Location ${locationId}` : "—")}
                    </td>
                    <td>{dateText}</td>
                    <td>
                      <StatusBadge
                        status={
                          value(r, "PUTAWAY_STATUS", "status") || "IN PROGRESS"
                        }
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {!loading && rows.length === 0 && (
          <div className="empty-state">No receiving records found.</div>
        )}
      </section>

      {open && (
        <Modal
          title="New Receiving"
          onClose={() => !saving && setOpen(false)}
          footer={
            <>
              <button
                className="secondary-button"
                type="button"
                onClick={() => setOpen(false)}
                disabled={saving}
              >
                Cancel
              </button>
              <button
                className="primary-button"
                type="submit"
                form="receive-form"
                disabled={saving}
              >
                {saving ? "Saving..." : "Receive Stock"}
              </button>
            </>
          }
        >
          <form id="receive-form" className="form-grid" onSubmit={save}>
            <label>
              Product
              <select
                required
                value={form.productId}
                onChange={(e) => setForm({ ...form, productId: e.target.value })}
              >
                <option value="">Select product</option>
                {products.map((p) => (
                  <option key={p.productId} value={p.productId}>
                    {p.productName} ({p.productId})
                  </option>
                ))}
              </select>
            </label>

            <label>
              Supplier
              <select
                required
                value={form.supplierId}
                onChange={(e) => setForm({ ...form, supplierId: e.target.value })}
              >
                <option value="">Select supplier</option>
                {suppliers.map((s) => (
                  <option key={s.supplierId} value={s.supplierId}>
                    {s.supplierName}
                  </option>
                ))}
              </select>
            </label>

            <label>
              Putaway Location
              <select
                required
                value={form.locationId}
                onChange={(e) => setForm({ ...form, locationId: e.target.value })}
              >
                <option value="">Select location</option>
                {locations.map((l) => (
                  <option key={l.locationId} value={l.locationId}>
                    {l.code || `Location ${l.locationId}`} {l.zone ? `· ${l.zone}` : ""}
                  </option>
                ))}
              </select>
            </label>

            <label>
              Quantity
              <input
                type="number"
                min="1"
                required
                value={form.receivedQuantity}
                onChange={(e) =>
                  setForm({ ...form, receivedQuantity: e.target.value })
                }
              />
            </label>

            <label>
              Date
              <input
                type="date"
                required
                value={form.receivedDate}
                onChange={(e) => setForm({ ...form, receivedDate: e.target.value })}
              />
            </label>

            <label>
              Status
              <select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value })}
              >
                <option value="COMPLETED">COMPLETED</option>
                <option value="IN PROGRESS">IN PROGRESS</option>
              </select>
            </label>
          </form>
        </Modal>
      )}
    </div>
  );
}
