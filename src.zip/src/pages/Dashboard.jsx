import {useMemo,useState} from "react";
import StatCard from "../components/dashboard/StatCard";
import RecentOrders from "../components/dashboard/RecentOrders";
import SmartAlerts from "../components/dashboard/SmartAlerts";
import WarehouseSummary from "../components/dashboard/WarehouseSummary";
import SectionCard from "../components/common/SectionCard";

export default function Dashboard({state,navigate,notify,globalSearch}){
 const [month,setMonth]=useState("This Month");
 const q=globalSearch.trim().toLowerCase();
 const products=state.products||[];
 const low=state.inventory.filter(x=>Number(x.availableStock)<=Number(x.reorderLevel));
 const available=state.inventory.reduce((a,x)=>a+Number(x.availableStock||0),0);
 const pending=state.orders.filter(x=>x.orderStatus!=="SHIPPED").length;
 const searchResults=useMemo(()=>{if(!q)return[];const rows=[];products.forEach(x=>{if(`${x.productId} ${x.productName} ${x.category}`.toLowerCase().includes(q))rows.push({type:"Product",title:x.productName,detail:x.productId,go:"Inventory"});});state.suppliers.forEach(x=>{if(`${x.supplierId} ${x.supplierName} ${x.phone} ${x.email}`.toLowerCase().includes(q))rows.push({type:"Supplier",title:x.supplierName,detail:x.email,go:"Suppliers"});});state.orders.forEach(x=>{if(`${x.orderId} ${x.customerName} ${x.productName} ${x.orderStatus}`.toLowerCase().includes(q))rows.push({type:"Order",title:`Order #${x.orderId}`,detail:x.customerName,go:"Orders"});});return rows.slice(0,8);},[q,products,state.suppliers,state.orders]);
 return <div className="page-content">
  <div className="page-title"><div><h1>Dashboard</h1><p>Warehouse Management System · live frontend workspace</p></div><div className="dashboard-navigation"><button onClick={()=>navigate("Inventory")}>Inventory</button><button onClick={()=>navigate("Reports")}>Reports</button></div></div>
  {q&&<section className="section-card global-results"><div className="section-card-header"><div><h2>Search Results</h2><p>Matches for “{globalSearch}”</p></div><button className="secondary-button" onClick={()=>navigate("Dashboard")}>Close</button></div>{searchResults.length?<div className="global-result-grid">{searchResults.map((r,i)=><button key={`${r.type}-${i}`} onClick={()=>navigate(r.go)}><span>{r.type}</span><strong>{r.title}</strong><small>{r.detail}</small></button>)}</div>:<div className="empty-state">No products, suppliers or orders matched your search.</div>}</section>}
  <div className="stats-grid">
   <StatCard icon="▣" label="Total Products" value={products.length} subtitle="Products in inventory" trend="↑ Active" tone="blue" onClick={()=>navigate("Inventory")}/>
   <StatCard icon="◫" label="Available Stock" value={available.toLocaleString()} subtitle="Units currently available" trend="↑ Live" tone="green" onClick={()=>navigate("Inventory")}/>
   <StatCard icon="⚠" label="Low Stock Items" value={low.length} subtitle="Items need attention" trend="Action" tone="orange" onClick={()=>navigate("Inventory")}/>
   <StatCard icon="🛒" label="Pending Orders" value={pending} subtitle="Orders awaiting shipment" trend="View" tone="purple" onClick={()=>navigate("Orders")}/>
  </div>
  <div className="dashboard-grid">
   <div className="dashboard-left"><SectionCard><div className="stock-panel"><div className="panel-heading"><div><h3>Stock Overview</h3><p>Monthly inventory movement</p></div><select className="stock-period" value={month} onChange={e=>setMonth(e.target.value)}><option>This Month</option><option>Last 6 Months</option><option>This Year</option></select></div><div className="stock-chart"><div className="chart-area">{state.stockOverview.slice(month==="This Year"?0:month==="Last 6 Months"?6:0,month==="This Year"?12:month==="Last 6 Months"?12:6).map((x)=><div className="chart-col" key={x.month}><div className="bars"><i style={{height:`${Math.max(5,x.inStock/7)}%`}} title={`In Stock ${x.inStock}`}/><b style={{height:`${Math.max(4,x.outOfStock/7)}%`}} title={`Out of Stock ${x.outOfStock}`}/></div><span>{x.month}</span></div>)}</div><div className="chart-legend"><span><i className="legend-blue"/>In Stock</span><span><i className="legend-red"/>Out of Stock</span></div></div></div></SectionCard><SmartAlerts alerts={low} navigate={navigate}/></div>
   <div className="dashboard-right"><WarehouseSummary warehouse={state.warehouse} locations={state.locations}/><RecentOrders orders={state.orders.slice(0,5)} navigate={navigate}/></div>
  </div>
 </div>;
}
